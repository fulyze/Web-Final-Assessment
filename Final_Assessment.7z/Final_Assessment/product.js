/*<!--********************************************************************
I declare that my assignment is wholly my own work in accordance with Seneca
Academic Policy. No part of this assignment has been copied manually or
electronically from any other source (including web sites) except for the
information supplied by the WEB222 instructors and / or made available in this
assignment for my use.
I also declare that no part of this assignment has been distributed to other
students.
Name: Jason Ting Hey Chu
Dated: April 6th, 2022
************************************************************************-->*/

button.onclick = function validate() {
    const ID = document.querySelector('input[name="product_ID"]');
    const desc = document.querySelector('input[name="product_description"]');
    const price = document.querySelector('input[name="product_price"]');

    const username = document.querySelector('textarea[name="supplier_username"]');
    
    const type1 = document.querySelector('textarea[name="supplier_type1"]');
    const type2 = document.querySelector('textarea[name="supplier_type2"]');
    const type3 = document.querySelector('textarea[name="supplier_type3"]');

    const email = document.querySelector('input[name="supplier_email"]');

    const emailpattern = "/^([w-.]+@([w-]+.)+[w-]{2,4})?$/";

    let valid = true;

    
    if(!ID || ID == NaN || ID < 9999999 || ID > 99999999){
        alert('Please enter a valid Product ID (8 digits)');
        document.form1.product_ID.focus();
        return false;
    }
    if (desc.length <= 20 || desc[0] != upper(desc[0])) {
        alert('Please enter a valid Description (More than 20 characters)');
        document.form1.product_price.focus();
        return false;
    }
    if (price == ""){
        alert('Please enter a valid Price (Less than 1000)');
        document.form1.product_price.focus();
        return false;
    }
    if (username[0]!=alpha(username[0]) || username.length < 6){
        alert('Please enter a valid Username (8 digits)');
        document.form1.supplier_username.focus();        
        return false;
    }
    if (type1 == "" && type2 == "" && type3 == "" ){
        alert('Please select at least 1 box!');
        document.form1.supplier_type.focus();        
        return false;
    }
    if (email.pattern != emailpattern){
        alert('Please enter a valid Email(/^([w-.]+@([w-]+.)+[w-]{2,4})?$/)');
        document.form1.supplier_email.focus();        
        return false;
    }
    return true;
}